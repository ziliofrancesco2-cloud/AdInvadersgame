package com.crowclaw.adinvaders

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * Schermata di gioco retro: ogni annuncio bloccato diventa un invasore pixel
 * che scende dall'alto; la navicella lo insegue e lo abbatte.
 */
class GameView(context: Context) : View(context) {

    // ---------- sprite pixel art ----------
    private val shipSprite = arrayOf(
        ".....#.....",
        "....###....",
        "....#+#....",
        "...#####...",
        ".#.#####.#.",
        "###########",
        "##.#####.##",
        "#...#.#...#",
    )
    private val invaderA = arrayOf(
        "...#####...",
        ".#########.",
        "##..###..##",
        "###########",
        ".#.#.#.#.#.",
        "#.#.....#.#",
    )
    private val invaderB = arrayOf(
        "...#####...",
        ".#########.",
        "##..###..##",
        "###########",
        ".#.#.#.#.#.",
        ".#.#...#.#.",
    )

    private val dp = resources.displayMetrics.density
    private val px = 3f * dp                      // dimensione di un "pixel" retro
    private val palette = intArrayOf(
        Color.parseColor("#FF3BD4"), Color.parseColor("#FFD23B"),
        Color.parseColor("#3BC8FF"), Color.parseColor("#FF6B3B"),
        Color.parseColor("#B07BFF"),
    )
    private val green = Color.parseColor("#39FF88")

    // ---------- stato ----------
    private class Star(var x: Float, var y: Float, val speed: Float, val size: Float)
    private class Invader(val label: String, var x: Float, var y: Float, val color: Int, val phase: Float)
    private class Bullet(var x: Float, var y: Float)
    private class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val color: Int)
    private class Popup(var x: Float, var y: Float, var life: Float, val text: String)

    private val stars = ArrayList<Star>()
    private val invaders = ArrayList<Invader>()
    private val pending = ArrayDeque<String>()
    private val bullets = ArrayList<Bullet>()
    private val particles = ArrayList<Particle>()
    private val popups = ArrayList<Popup>()

    private var shipX = 0f
    private var targetX = -1f
    private var cooldown = 0f
    private var shake = 0f
    private var time = 0f
    private var lastFrame = 0L
    private var spawnTimer = 0f

    var score: Long = 0
    var shieldOn = false
    var listSize = 0

    private val paint = Paint().apply { isAntiAlias = false }
    private val text = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    /** Chiamato a ogni annuncio bloccato. */
    fun addInvader(domain: String) {
        if (pending.size < 50) pending.addLast(domain)
    }

    // ---------- loop ----------
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        stars.clear()
        repeat(90) {
            stars += Star(Random.nextFloat() * w, Random.nextFloat() * h,
                (20 + Random.nextFloat() * 120) * dp, if (Random.nextInt(5) == 0) 2 * dp else dp)
        }
        shipX = w / 2f
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastFrame == 0L) 0f else ((now - lastFrame) / 1e9f).coerceAtMost(0.05f)
        lastFrame = now
        update(dt)

        canvas.drawColor(Color.parseColor("#05030F"))
        canvas.save()
        if (shake > 0) canvas.translate((Random.nextFloat() - .5f) * shake, (Random.nextFloat() - .5f) * shake)

        drawStars(canvas)
        drawInvaders(canvas)
        drawBullets(canvas)
        drawParticles(canvas)
        drawShip(canvas)
        drawPopups(canvas)
        canvas.restore()
        drawHud(canvas)
        drawScanlines(canvas)

        postInvalidateOnAnimation()
    }

    private val shipY get() = height - 150 * dp

    private fun update(dt: Float) {
        time += dt
        shake = (shake - 40 * dt).coerceAtLeast(0f)

        for (s in stars) { s.y += s.speed * dt; if (s.y > height) { s.y = 0f; s.x = Random.nextFloat() * width } }

        // Fa entrare i nuovi invasori uno alla volta
        spawnTimer -= dt
        if (spawnTimer <= 0 && pending.isNotEmpty() && invaders.size < 10) {
            val margin = 70 * dp
            invaders += Invader(pending.removeFirst(),
                margin + Random.nextFloat() * (width - 2 * margin), 90 * dp,
                palette.random(), Random.nextFloat() * 6f)
            spawnTimer = 0.35f
        }

        val fall = 28 * dp
        for (inv in invaders) inv.y += fall * dt

        // La navicella insegue l'invasore più basso (pilota automatico)
        val target = invaders.maxByOrNull { it.y }
        val goal = when {
            target != null -> invaderX(target)
            targetX >= 0 -> targetX
            else -> width / 2f + sin(time * 0.8f) * width * 0.25f
        }
        val dx = goal - shipX
        shipX += dx.coerceIn(-420 * dp * dt, 420 * dp * dt)

        cooldown -= dt
        if (target != null && abs(dx) < 14 * dp && cooldown <= 0) fire()

        // Proiettili
        val bIt = bullets.iterator()
        while (bIt.hasNext()) {
            val b = bIt.next()
            b.y -= 900 * dp * dt
            if (b.y < 0) { bIt.remove(); continue }
            val hit = invaders.firstOrNull { abs(invaderX(it) - b.x) < 6 * px && b.y in it.y..(it.y + 6 * px) }
            if (hit != null) { bIt.remove(); explode(hit) }
        }
        // Se un invasore arriva troppo in basso esplode comunque: è già bloccato!
        invaders.filter { it.y > shipY - 30 * dp }.forEach { explode(it) }

        val pIt = particles.iterator()
        while (pIt.hasNext()) {
            val p = pIt.next()
            p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 300 * dp * dt; p.life -= dt
            if (p.life <= 0) pIt.remove()
        }
        val uIt = popups.iterator()
        while (uIt.hasNext()) { val u = uIt.next(); u.y -= 40 * dp * dt; u.life -= dt; if (u.life <= 0) uIt.remove() }
    }

    private fun invaderX(inv: Invader) = inv.x + sin(time * 2f + inv.phase) * 30 * dp

    private fun fire() {
        bullets += Bullet(shipX, shipY - 4 * px)
        cooldown = 0.22f
    }

    private fun explode(inv: Invader) {
        if (!invaders.remove(inv)) return
        val cx = invaderX(inv); val cy = inv.y + 3 * px
        repeat(28) {
            val a = Random.nextFloat() * 6.283f
            val sp = (80 + Random.nextFloat() * 260) * dp
            particles += Particle(cx, cy, kotlin.math.cos(a) * sp, sin(a) * sp - 120 * dp,
                0.5f + Random.nextFloat() * 0.6f, if (Random.nextBoolean()) inv.color else Color.WHITE)
        }
        popups += Popup(cx, cy, 1.2f, "BLOCCATO!")
        shake = 10 * dp
        score++
    }

    // ---------- disegno ----------
    private fun drawSprite(c: Canvas, sprite: Array<String>, cx: Float, top: Float, color: Int, accent: Int = Color.WHITE) {
        val w = sprite[0].length * px
        val left = cx - w / 2
        for ((r, row) in sprite.withIndex()) for ((i, ch) in row.withIndex()) {
            if (ch == '.') continue
            paint.color = if (ch == '+') accent else color
            c.drawRect(left + i * px, top + r * px, left + (i + 1) * px, top + (r + 1) * px, paint)
        }
    }

    private fun drawStars(c: Canvas) {
        paint.color = Color.argb(180, 255, 255, 255)
        for (s in stars) c.drawRect(s.x, s.y, s.x + s.size, s.y + s.size, paint)
    }

    private fun drawShip(c: Canvas) {
        // fiamma del motore
        val flick = if ((time * 20).toInt() % 2 == 0) 2 else 3
        paint.color = Color.parseColor("#FFD23B")
        c.drawRect(shipX - px, shipY + 8 * px, shipX + px, shipY + (8 + flick) * px, paint)
        drawSprite(c, shipSprite, shipX, shipY, green, Color.parseColor("#FF3BD4"))
    }

    private fun drawInvaders(c: Canvas) {
        val frame = if ((time * 3).toInt() % 2 == 0) invaderA else invaderB
        text.textAlign = Paint.Align.CENTER
        text.textSize = 10 * dp
        for (inv in invaders) {
            val x = invaderX(inv)
            drawSprite(c, frame, x, inv.y, inv.color)
            // targhetta "AD"
            paint.color = Color.BLACK
            c.drawRect(x - 2.5f * px, inv.y + 2 * px, x + 2.5f * px, inv.y + 3 * px, paint)
            text.color = inv.color
            val label = if (inv.label.length > 24) "…" + inv.label.takeLast(23) else inv.label
            c.drawText(label, x, inv.y + 6 * px + 13 * dp, text)
        }
    }

    private fun drawBullets(c: Canvas) {
        paint.color = green
        for (b in bullets) c.drawRect(b.x - px / 2, b.y - 4 * px, b.x + px / 2, b.y, paint)
    }

    private fun drawParticles(c: Canvas) {
        for (p in particles) {
            paint.color = p.color
            paint.alpha = (255 * (p.life.coerceAtMost(1f))).toInt()
            c.drawRect(p.x, p.y, p.x + px, p.y + px, paint)
        }
        paint.alpha = 255
    }

    private fun drawPopups(c: Canvas) {
        text.textAlign = Paint.Align.CENTER
        text.textSize = 14 * dp
        for (u in popups) {
            text.color = Color.argb((255 * u.life.coerceAtMost(1f)).toInt(), 255, 210, 59)
            c.drawText(u.text, u.x, u.y, text)
        }
    }

    private fun drawHud(c: Canvas) {
        text.textAlign = Paint.Align.LEFT
        text.textSize = 15 * dp
        text.color = Color.WHITE
        c.drawText("SCORE %06d".format(score), 16 * dp, 36 * dp, text)
        text.textAlign = Paint.Align.RIGHT
        text.color = if (shieldOn) green else Color.parseColor("#FF3B5C")
        val blink = shieldOn || (time * 2).toInt() % 2 == 0
        if (blink) c.drawText(if (shieldOn) "SCUDO ON" else "SCUDO OFF", width - 16 * dp, 36 * dp, text)
        text.textAlign = Paint.Align.LEFT
        text.textSize = 10 * dp
        text.color = Color.argb(160, 255, 255, 255)
        c.drawText("LISTA: $listSize DOMINI", 16 * dp, 56 * dp, text)
        if (invaders.isEmpty() && pending.isEmpty()) {
            text.textAlign = Paint.Align.CENTER
            text.textSize = 12 * dp
            text.color = Color.argb(140, 255, 255, 255)
            c.drawText(if (shieldOn) "IN ATTESA DI INVASORI…" else "ATTIVA LO SCUDO PER INIZIARE", width / 2f, height / 2f, text)
        }
    }

    private fun drawScanlines(c: Canvas) {
        paint.color = Color.argb(28, 0, 0, 0)
        var y = 0f
        while (y < height) { c.drawRect(0f, y, width.toFloat(), y + dp, paint); y += 3 * dp }
    }

    // Tocco: sposta la navicella e spara
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                targetX = e.x
                if (invaders.isEmpty() && cooldown <= 0) fire()
            }
            MotionEvent.ACTION_UP -> targetX = -1f
        }
        return true
    }
}
