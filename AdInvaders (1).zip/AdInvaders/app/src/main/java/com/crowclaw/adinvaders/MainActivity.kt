package com.crowclaw.adinvaders

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var game: GameView
    private lateinit var toggle: Button
    private val handler = Handler(Looper.getMainLooper())
    private val listener = BlockEvents.Listener { game.addInvader(it) }

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) startShield()
            else Toast.makeText(this, "Permesso VPN negato", Toast.LENGTH_SHORT).show()
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val demoAds = listOf(
        "ads.doubleclick.net", "pagead2.googlesyndication.com", "graph.facebook.ads",
        "ads.tiktok.com", "cdn.taboola.com", "adservice.google.it", "ads.unity3d.com",
        "app-measurement.com", "outbrain.com", "popads.net",
    )

    private val refresh = object : Runnable {
        override fun run() {
            game.shieldOn = BlockEvents.vpnRunning
            toggle.text = if (BlockEvents.vpnRunning) "■ DISATTIVA" else "▶ ATTIVA SCUDO"
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BlockList.load(this)

        game = GameView(this)
        val dp = resources.displayMetrics.density

        toggle = retroButton("▶ ATTIVA SCUDO", "#39FF88") {
            if (BlockEvents.vpnRunning) stopShield() else requestShield()
        }
        val demo = retroButton("DEMO", "#FF3BD4") {
            demoAds.shuffled().take(5).forEach(game::addInvader)
        }
        val update = retroButton("AGGIORNA LISTA", "#3BC8FF") { downloadList() }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), (24 * dp).toInt())
            val lp = { w: Float -> LinearLayout.LayoutParams(0, (52 * dp).toInt(), w).apply { marginStart = (4 * dp).toInt(); marginEnd = (4 * dp).toInt() } }
            addView(toggle, lp(1.4f)); addView(demo, lp(0.8f)); addView(update, lp(1.3f))
        }

        setContentView(FrameLayout(this).apply {
            addView(game, FrameLayout.LayoutParams(-1, -1))
            addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        })

        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        BlockEvents.add(listener)
        game.score = AdBlockVpnService.blockedCount(this)
        game.listSize = BlockList.size
        handler.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        BlockEvents.remove(listener)
        handler.removeCallbacks(refresh)
    }

    private fun requestShield() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startShield()
    }

    private fun startShield() {
        startForegroundService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START))
    }

    private fun stopShield() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
    }

    private fun downloadList() {
        Toast.makeText(this, "Scarico la lista completa…", Toast.LENGTH_SHORT).show()
        thread {
            val msg = try {
                val n = BlockList.downloadFull(this)
                runOnUiThread { game.listSize = n }
                "Lista aggiornata: $n domini"
            } catch (e: Exception) {
                "Download non riuscito: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }
    }

    private fun retroButton(label: String, color: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = true
        textSize = 12f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setTextColor(Color.parseColor(color))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC05030F"))
            setStroke((2 * resources.displayMetrics.density).toInt(), Color.parseColor(color))
        }
        setOnClickListener { onClick() }
    }
}
