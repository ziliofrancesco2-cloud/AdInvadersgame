package com.crowclaw.adinvaders

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Insieme dei domini da bloccare: lista base negli assets + lista scaricata (se presente). */
object BlockList {
    private const val DOWNLOADED = "blocklist_full.txt"
    const val FULL_LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"

    @Volatile private var domains: Set<String> = emptySet()

    val size: Int get() = domains.size

    fun load(context: Context) {
        val set = HashSet<String>(100_000)
        context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            lines.forEach { parseLine(it)?.let(set::add) }
        }
        val file = File(context.filesDir, DOWNLOADED)
        if (file.exists()) {
            file.bufferedReader().useLines { lines -> lines.forEach { parseLine(it)?.let(set::add) } }
        }
        domains = set
    }

    /** Accetta sia "dominio.com" che il formato hosts "0.0.0.0 dominio.com". */
    private fun parseLine(raw: String): String? {
        val line = raw.substringBefore('#').trim().lowercase()
        if (line.isEmpty()) return null
        val parts = line.split(Regex("\\s+"))
        val host = if (parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1")) parts[1] else parts[0]
        if (host == "localhost" || host == "0.0.0.0" || !host.contains('.')) return null
        return host
    }

    /** Blocca il dominio e tutti i suoi sottodomini. */
    fun isBlocked(name: String): Boolean {
        var d = name.lowercase().trimEnd('.')
        val set = domains
        while (true) {
            if (set.contains(d)) return true
            val dot = d.indexOf('.')
            if (dot < 0) return false
            d = d.substring(dot + 1)
        }
    }

    /** Scarica la lista completa. Da chiamare fuori dal main thread. */
    fun downloadFull(context: Context): Int {
        val conn = URL(FULL_LIST_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        try {
            val tmp = File(context.filesDir, "$DOWNLOADED.tmp")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(File(context.filesDir, DOWNLOADED))
        } finally {
            conn.disconnect()
        }
        load(context)
        return size
    }
}
