package com.crowclaw.adinvaders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Blocco annunci via "VPN" locale che intercetta solo il DNS.
 * Nessun traffico lascia il telefono verso server nostri: le richieste DNS lecite
 * vengono inoltrate a un DNS pubblico, quelle dei domini pubblicitari ricevono NXDOMAIN.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.crowclaw.adinvaders.START"
        const val ACTION_STOP = "com.crowclaw.adinvaders.STOP"
        private const val VPN_ADDRESS = "10.111.222.2"
        private const val VPN_DNS = "10.111.222.1"
        private const val UPSTREAM_DNS = "1.1.1.1"
        private const val CHANNEL = "adinvaders"
        private const val NOTIF_ID = 42

        fun blockedCount(ctx: Context): Long =
            ctx.getSharedPreferences("stats", MODE_PRIVATE).getLong("blocked", 0)
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var out: FileOutputStream? = null
    private var pool: ExecutorService? = null
    private val lastEmit = ConcurrentHashMap<String, Long>()
    private val vpnDnsBytes = InetAddress.getByName(VPN_DNS).address

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (tun == null) startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        BlockList.load(this)
        val builder = Builder()
            .setSession("Ad Invaders")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32)   // solo il traffico DNS passa da qui
            .setBlocking(true)
        try { builder.addDisallowedApplication(packageName) } catch (_: Exception) {}

        val fd = builder.establish() ?: return
        tun = fd
        out = FileOutputStream(fd.fileDescriptor)
        pool = Executors.newFixedThreadPool(8)
        BlockEvents.vpnRunning = true

        worker = Thread({
            val input = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            try {
                while (!Thread.currentThread().isInterrupted) {
                    val n = input.read(buf)
                    if (n > 0) handlePacket(buf.copyOf(n))
                }
            } catch (_: Exception) {
                // tun chiusa: usciamo
            }
        }, "adinvaders-dns").also { it.start() }
    }

    private fun stopVpn() {
        BlockEvents.vpnRunning = false
        worker?.interrupt(); worker = null
        pool?.shutdownNow(); pool = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null; out = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onRevoke() { stopVpn(); stopSelf() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    // ---------- gestione pacchetti ----------

    private fun handlePacket(pkt: ByteArray) {
        if (pkt.size < 28) return
        if ((pkt[0].toInt() ushr 4) != 4) return                 // solo IPv4
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17) return                         // solo UDP
        if (pkt.size < ihl + 8) return
        val srcIp = pkt.copyOfRange(12, 16)
        val srcPort = u16(pkt, ihl)
        val dstPort = u16(pkt, ihl + 2)
        if (dstPort != 53) return

        val query = pkt.copyOfRange(ihl + 8, pkt.size)
        val q = parseQuestion(query) ?: return

        if (BlockList.isBlocked(q.first)) {
            writeReply(srcIp, srcPort, nxDomain(query, q.second))
            onBlocked(q.first)
        } else {
            pool?.execute { forward(query, srcIp, srcPort) }
        }
    }

    private fun forward(query: ByteArray, srcIp: ByteArray, srcPort: Int) {
        try {
            DatagramSocket().use { sock ->
                protect(sock)
                sock.soTimeout = 5000
                sock.send(DatagramPacket(query, query.size, InetAddress.getByName(UPSTREAM_DNS), 53))
                val resp = DatagramPacket(ByteArray(4096), 4096)
                sock.receive(resp)
                writeReply(srcIp, srcPort, resp.data.copyOf(resp.length))
            }
        } catch (_: Exception) {
            // timeout o rete assente: l'app riproverà da sola
        }
    }

    private fun onBlocked(domain: String) {
        val prefs = getSharedPreferences("stats", MODE_PRIVATE)
        prefs.edit().putLong("blocked", prefs.getLong("blocked", 0) + 1).apply()
        // Evita di inondare il gioco con la stessa richiesta ripetuta
        val now = System.currentTimeMillis()
        val prev = lastEmit[domain] ?: 0L
        if (now - prev > 3000) {
            lastEmit[domain] = now
            BlockEvents.emit(domain)
        }
    }

    /** Ritorna (nome dominio, offset di fine della sezione question). */
    private fun parseQuestion(dns: ByteArray): Pair<String, Int>? {
        if (dns.size < 12) return null
        if ((dns[2].toInt() and 0x80) != 0) return null          // non è una query
        if (u16(dns, 4) < 1) return null
        val sb = StringBuilder()
        var pos = 12
        while (pos < dns.size) {
            val len = dns[pos].toInt() and 0xFF
            if (len == 0) { pos++; break }
            if (len and 0xC0 != 0) return null
            if (pos + 1 + len > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, pos + 1, len, Charsets.US_ASCII))
            pos += 1 + len
        }
        val end = pos + 4                                        // QTYPE + QCLASS
        if (end > dns.size || sb.isEmpty()) return null
        return sb.toString() to end
    }

    private fun nxDomain(query: ByteArray, questionEnd: Int): ByteArray {
        val r = query.copyOf(questionEnd)
        r[2] = (0x80 or (query[2].toInt() and 0x79)).toByte()   // QR=1, mantiene opcode e RD
        r[3] = 0x83.toByte()                                     // RA=1, RCODE=3 (NXDOMAIN)
        for (i in 6 until 12) r[i] = 0                           // AN/NS/AR = 0
        return r
    }

    private fun writeReply(dstIp: ByteArray, dstPort: Int, payload: ByteArray) {
        val total = 28 + payload.size
        val p = ByteArray(total)
        p[0] = 0x45; p[2] = (total ushr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40; p[8] = 64; p[9] = 17
        System.arraycopy(vpnDnsBytes, 0, p, 12, 4)
        System.arraycopy(dstIp, 0, p, 16, 4)
        val cs = ipChecksum(p, 20)
        p[10] = (cs ushr 8).toByte(); p[11] = cs.toByte()
        // UDP (checksum 0 = non usato, valido in IPv4)
        p[20] = 0; p[21] = 53
        p[22] = (dstPort ushr 8).toByte(); p[23] = dstPort.toByte()
        val udpLen = 8 + payload.size
        p[24] = (udpLen ushr 8).toByte(); p[25] = udpLen.toByte()
        System.arraycopy(payload, 0, p, 28, payload.size)
        val o = out ?: return
        synchronized(o) { try { o.write(p) } catch (_: Exception) {} }
    }

    private fun ipChecksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) { sum += u16(b, i); i += 2 }
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv() and 0xFFFF
    }

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    // ---------- notifica ----------

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Scudo anti-annunci", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AdBlockVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_ship)
            .setContentTitle("Ad Invaders in pattuglia 🚀")
            .setContentText("La navicella sta abbattendo gli annunci")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Atterra", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
