package com.crowclaw.adinvaders

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/** Piccolo bus di eventi: il servizio VPN avvisa il gioco a ogni annuncio bloccato. */
object BlockEvents {
    fun interface Listener { fun onBlocked(domain: String) }

    private val listeners = CopyOnWriteArrayList<Listener>()
    private val main = Handler(Looper.getMainLooper())

    @Volatile var vpnRunning = false
        internal set

    fun add(l: Listener) { listeners.add(l) }
    fun remove(l: Listener) { listeners.remove(l) }

    fun emit(domain: String) {
        main.post { listeners.forEach { it.onBlocked(domain) } }
    }
}
