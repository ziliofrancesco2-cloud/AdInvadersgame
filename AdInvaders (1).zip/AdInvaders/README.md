# Ad Invaders 🚀

Blocco annunci per Android con una navicella retro che abbatte ogni annuncio bloccato.

## Come funziona
- **Scudo**: una "VPN" locale (`VpnService`) che intercetta solo le richieste DNS.
  I domini pubblicitari ricevono NXDOMAIN, gli altri vengono inoltrati a 1.1.1.1.
  Nessun dato passa da server esterni oltre al DNS pubblico.
- **Gioco**: ogni dominio bloccato diventa un invasore pixel col nome del dominio.
  La navicella lo insegue col pilota automatico e lo fa esplodere. Puoi anche toccare
  lo schermo per muoverla e sparare quando non ci sono invasori.
- **DEMO**: fa scendere 5 invasori finti per vedere l'animazione.
- **AGGIORNA LISTA**: scarica la lista StevenBlack (~80.000 domini) oltre a quella base.

## Compilare
1. Apri la cartella `AdInvaders` in Android Studio (Ladybug o più recente).
2. Lascia che faccia il Gradle sync (genera da solo il wrapper se manca).
3. Collega il telefono con il debug USB attivo e premi ▶ Run.
   Oppure: Build → Build APK(s) e installa `app/build/outputs/apk/debug/app-debug.apk`.

## Limiti da sapere
- Blocca gli annunci che arrivano da domini dedicati (banner nelle app, tracker, pop-up).
  **Non** blocca gli annunci di YouTube, Instagram o Facebook: arrivano dagli stessi
  server dei contenuti.
- Se in Impostazioni → Rete → **DNS privato** è impostato un provider, Android lo usa al
  posto dello scudo: mettilo su "Automatico" o "Disattivato".
- Android permette una sola VPN attiva per volta.
